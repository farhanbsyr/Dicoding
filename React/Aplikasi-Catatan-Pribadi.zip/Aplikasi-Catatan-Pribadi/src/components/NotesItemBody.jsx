import React from "react";

const NotesItemBody = ({ body }) => {
  return <p className="">{body}</p>;
};

export default NotesItemBody;
